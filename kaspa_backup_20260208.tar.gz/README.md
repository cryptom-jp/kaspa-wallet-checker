# Kaspa Wallet Balance Checker

Kaspaブロックチェーンのアドレス残高を確認するツール（gRPC版）

## 機能

- ✅ Kaspaアドレスの残高取得（CLI/Web API）
- ✅ エラーハンドリング（リトライ、タイムアウト）
- ✅ 設定ファイル対応（config.yaml）
- ✅ 詳細ログ出力

## 技術スタック

- Python 3.14
- gRPC
- Flask + Flask-CORS
- PyYAML

## セットアップ

### 1. 仮想環境のセットアップ

\`\`\`bash
cd ~/KaspaDev
python3 -m venv kaspa_venv
source kaspa_venv/bin/activate
pip install -r requirements.txt
\`\`\`

### 2. Kaspaノードの起動

\`\`\`bash
./kaspad --utxoindex
\`\`\`

### 3. 設定ファイルの確認

\`src/kaspa_wallet/config.yaml\` を確認・編集

## 使用方法

### CLI

\`\`\`bash
cd ~/KaspaDev
source kaspa_venv/bin/activate
cd src/kaspa_wallet
python3 balance.py kaspa:qqk9m5z05ej8e0j4tmx9geaqw6zeexa46pllgqllv28krv0cpgr9ucl3x5gxp
\`\`\`

### Web API

\`\`\`bash
cd ~/KaspaDev
source kaspa_venv/bin/activate
cd server_py
python3 app.py
\`\`\`

ブラウザで \`http://127.0.0.1:5000/\` にアクセス

## API仕様

### GET /api/balance

**パラメータ：**
- \`address\` (required): Kaspaアドレス

**レスポンス例（成功）：**
\`\`\`json
{
  "address": "kaspa:qqk9...",
  "balance_sompi": 20000000,
  "balance_kas": 0.2,
  "status": "success"
}
\`\`\`

**レスポンス例（エラー）：**
\`\`\`json
{
  "error": "invalid_address",
  "message": "アドレスが短すぎます（最低40文字必要）",
  "address": "kaspa:..."
}
\`\`\`

## ディレクトリ構成

\`\`\`
~/KaspaDev/
├── src/kaspa_wallet/     # メインコード
│   ├── balance.py        # 残高取得
│   └── config.yaml       # 設定
├── server_py/            # Webサーバー
│   └── app.py
├── proto/                # gRPC定義
├── logs/                 # ログ
└── kaspa_venv/           # 仮想環境
\`\`\`

## トラブルシューティング

### gRPCエラー

\`\`\`bash
# Kaspaノードが起動しているか確認
ps aux | grep kaspad

# ポート確認
lsof -i :16110
\`\`\`

### ログ確認

\`\`\`bash
tail -f ~/KaspaDev/logs/balance.log
\`\`\`

## ライセンス

MIT License
